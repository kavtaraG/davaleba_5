const form = document.querySelector('.form');
const input = document.querySelector('input[name="username"]'); // მნიშვნელობის წაკითხვა
const ul = document.querySelector('.ul'); // დამატება
const btn1 = document.querySelector('#btn1');
const btn2 = document.querySelector('#btn2');

const errorMsg = document.querySelector('#errorMsg')

form.addEventListener('click', function(event){
    event.preventDefault();
    // errorMsg.textContent = '';
    if(input.value.trim() !== ''){
        
        const li = document.createElement('li');
        ul.appendChild(li);
        li.textContent = input.value;
        input.value = '';
        input.focus();

    }    
});



function removeItem(){
    const delItem2 = document.querySelector('li'); 
    
    
    delItem2.remove()
}
    
