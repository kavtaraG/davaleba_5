const grid = document.getElementById('grid');
const btn = document.getElementById('header-FBI');
const btn2 = document.querySelector('.btn2');
const userIdEl = document.getElementById('User-ID');
const passwordEl = document.getElementById('password');
const FBIform = document.getElementById('FBI-form');
const massageError = document.querySelector('.massageError');
const checkbox = document.querySelector('.checkbox');

let usernameID = 'kavtara_G';
let passwordID = '123456';

checkbox.addEventListener('change', function (eventCheckbox) {
    const checkbox = document.querySelector('.checkbox');
    checkbox.type = 'checkbox';
    // console.log(checkbox);
    const parent = eventCheckbox.target.parentNode;
    if(eventCheckbox.target.checked = true){
        parent.classList.add('.chBox');
    }
});

function headerFBI(){
    const grid = document.getElementById('grid')
    if(grid.style.display === 'none'){
        grid.style.display = 'block';
    }else{
        grid.style.display = 'none';
    }
};


checkbox.addEventListener('click', function checkSaver(eventCheckbox) {
    checkbox.type = 'checkbox';
    console.log(checkbox);
    const parent = eventCheckbox.target.parentNode;
    if(eventCheckbox.target.checked = true){
        parent.add(checkbox);
    }
});


btn2.addEventListener('click', function validate(eventCheckbox){
    eventCheckbox.preventDefault();
    
    const userID = document.querySelectorAll('input[value=""]').value;
    const password = document.querySelectorAll('input[value=""]').value;
                
    userIdEl.value = '';
    passwordEl.value = '';
    userIdEl.focus();
    passwordEl.focus();

                 if ((usernameID === userID) && ( passwordID === password)) {
                    
                    alert('Please enter the username.');
                    
                   
    
                }else if((usernameID !== userID) && ( passwordID === password)){
                    massageError.textContent = 'Access Denied';
                }else if(  ( passwordID !== password) && (usernameID === userID)){
                    massageError.textContent = 'Access Denied';
                }else{
                    massageError.textContent = 'Access Denied';
                }
            });