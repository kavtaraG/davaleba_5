const grid = document.getElementById('grid');
const btn = document.getElementById('header-FBI');
const btn2 = document.querySelector('.btn2');
const userIdEl = document.getElementById('User-ID');
const passwordEl = document.getElementById('password');
const FBIform = document.getElementById('FBI-form');
const massageError = document.querySelector('.massageError');
const checkbox = document.querySelector('.checkbox');
let usernameID = 'kavtara_G';
let passwordID = '123456';


const headerFBI = function(event){
    console.log(event);
    const grid = document.getElementById('grid');
    if(grid.style.display === 'none'){
        grid.style.display = 'block';
    }else{
        grid.style.display = 'none ';
    }
}

btn.addEventListener('click', headerFBI);



FBIform.addEventListener('submit', function validate (eventClick){

    eventClick.preventDefault();
    console.log(eventClick)
    const userID = document.getElementById('User-ID').value;
    const password = document.getElementById('password').value;
                
        

                 if ((usernameID === userID) && ( passwordID === password)) {
                    
                    alert('Please enter the username.');
                    
                    input.value = '';
                    Input.focus();
    
                }else if((usernameID !== userID) && ( passwordID === password)){
                    massageError.textContent = 'Access Denied';
                }else if(  ( passwordID !== password) && (usernameID === userID)){
                    massageError.textContent = 'Access Denied';
                }else{
                    massageError.textContent = 'Access Denied';
                }

    
    btn2.addEventListener('submit', validate);
})

