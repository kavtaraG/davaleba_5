const grid = document.getElementById('grid');
const btn = document.getElementById('header-FBI');
const btn2 = document.querySelector('.btn2');
const userIdEl = document.getElementById('User-ID');
const passwordEl = document.getElementById('password');
const FBIform = document.getElementById('FBI-form');
const massageError = document.querySelector('.massageError');
const checkbox = document.querySelector('.checkbox');
const checkbox2 = document.querySelector('input[name="checked"]');
let usernameID = 'kavtara_G';
let passwordID = '123456';


function headerFBI(){
    const grid = document.getElementById('grid')
    if(grid.style.display === 'none'){
        grid.style.display = 'block';
    }else{
        grid.style.display = 'none ';
    }
}


btn.addEventListener('click', headerFBI);





function checkSaver(eventCheckbox){
    const checkbox2 = document.querySelector('input[value="kavtara_G"]');
    const checkbox1 = document.querySelector('input[value=""]');
    
    if(eventCheckbox.target.checked){
        checkbox2.add(checkbox1);
    }
}

function validate(){
    eventClick.preventDefault();
    console.log(eventClick)
    const userID = document.getElementById('User-ID').value;
    const password = document.getElementById('password').value;
                
        

                 if ((usernameID === userID) && ( passwordID === password)) {
                    
                    alert('Please enter the username.');
                    
                    input.value = '';
                    Input.focus();
    
                }else if((usernameID !== userID) && ( passwordID === password)){
                    massageError.textContent = 'Access Denied';
                }else if(  ( passwordID !== password) && (usernameID === userID)){
                    massageError.textContent = 'Access Denied';
                }else{
                    massageError.textContent = 'Access Denied';
                }

                btn2.addEventListener('submit', validate);
}
